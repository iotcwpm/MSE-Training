
library(ggplot2)

library(shiny)

load("../pres.RData")

runApp("./")

